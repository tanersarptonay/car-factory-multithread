@FunctionalInterface
public interface ActionFunction {
    void apply();
}
